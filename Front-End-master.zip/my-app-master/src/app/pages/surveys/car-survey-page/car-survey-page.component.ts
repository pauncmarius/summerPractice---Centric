import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-survey-page',
  templateUrl: './car-survey-page.component.html',
  styleUrls: ['./car-survey-page.component.scss']
})
export class CarSurveyPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
