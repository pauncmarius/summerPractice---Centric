import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-survey-page',
  templateUrl: './food-survey-page.component.html',
  styleUrls: ['./food-survey-page.component.scss']
})
export class FoodSurveyPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
