import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-survey-page',
  templateUrl: './teacher-survey-page.component.html',
  styleUrls: ['./teacher-survey-page.component.scss']
})
export class TeacherSurveyPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
