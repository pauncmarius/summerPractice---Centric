import {AbstractControl} from "@angular/forms";

export interface User{
  email?: string,
  password?: string

}
